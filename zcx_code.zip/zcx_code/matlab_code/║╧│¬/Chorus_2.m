function [left_out, right_out] = dsound_chorus_processmix(in, number_blocks, modulation_period_samples, lookup_tab, level, chorusbuf, counter, MAX_SAMPLES, INTERPOLATION_SUBSAMPLES, sinc_table,INTERPOLATION_SAMPLES)
    %初始化输出
    left_out = zeros(size(in));
    right_out = zeros(size(in));
    
    %处理每个样本
    for sample_index = 1:length(in)
        d_in = in(sample_index);
        d_out = 0.0;
        
        %将当前样本写入循环缓冲区
        chorusbuf(counter) = d_in;
        
        %遍历每个合唱块
        for i = 1:number_blocks
            %计算合唱块的延迟（以亚样本为单位）
            pos_subsamples = (INTERPOLATION_SUBSAMPLES * counter - lookup_tab(mod(counter, modulation_period_samples)));
            pos_samples = floor(pos_subsamples / INTERPOLATION_SUBSAMPLES);
            pos_subsamples = mod(pos_subsamples, INTERPOLATION_SUBSAMPLES);
            
            %应用插值并累加延迟信号
            for ii = 1:INTERPOLATION_SAMPLES
                delay_index = mod(pos_samples - ii + 1, MAX_SAMPLES);
                d_out = d_out + chorusbuf(delay_index) * sinc_table(ii, pos_subsamples + 1);
            end
            
            %更新调制相位
            counter = mod(counter + 1, modulation_period_samples);
        end
        
        %应用合唱效果级别并累加到输出
        d_out = d_out * level;
        
        left_out(sample_index) = left_out(sample_index) + d_out;
        right_out(sample_index) = right_out(sample_index) + d_out;
        
        %在循环缓冲区中向前移动
        counter = mod(counter + 1, MAX_SAMPLES);
    end
end


% 定义合唱效果器参数
MAX_SAMPLES = 1024; % 循环缓冲区的最大样本数
INTERPOLATION_SUBSAMPLES = 8; % 插值的亚样本数
INTERPOLATION_SAMPLES = 4; % 插值样本数
modulation_period_samples = 100; % 调制周期样本数
number_blocks = 3; % 合唱块的数量
level = 0.5; % 合唱效果的级别

% 初始化合唱效果器状态
lookup_tab = linspace(0, modulation_period_samples-1, modulation_period_samples); % 需要填充的查找表
chorusbuf = zeros(1, MAX_SAMPLES); % 循环缓冲区
counter = 1; % 缓冲区计数器

% 初始化 sinc 插值表
sinc_table = zeros(INTERPOLATION_SAMPLES, INTERPOLATION_SUBSAMPLES * MAX_SAMPLES);
for i = 1:INTERPOLATION_SAMPLES
    for j = 1:(INTERPOLATION_SUBSAMPLES * MAX_SAMPLES)
        sinc_index = (i - 1) + (j - 1) / INTERPOLATION_SUBSAMPLES;
        sinc_table(i, j) = sinc(sinc_index);
    end
end

% % 创建输入信号
% Fs = 44100; % 采样频率
% t = 0:1/Fs:1-1/Fs; % 时间向量
% input_signal = 0.5 * sin(2 * pi * 440 * t); % 输入信号，例如440Hz的正弦波
[buffer, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段.wav'); 
input_signal=buffer( :,1);
% 调用合唱效果处理函数
[left_out, right_out] = dsound_chorus_processmix(input_signal, number_blocks, modulation_period_samples, lookup_tab, level, chorusbuf, counter, MAX_SAMPLES, INTERPOLATION_SUBSAMPLES, sinc_table,INTERPOLATION_SAMPLES);
buffer_1=[left_out, right_out];
fprintf('wancheng');
audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段合唱.wav', buffer_1, fs);

% % 播放输出信号
% sound(left_out, Fs); % 播放左声道输出
% pause(length(left_out) / Fs + 0.5); % 等待音频播放完成
% 
% % 绘制输入和输出信号
% figure;
% subplot(2,1,1);
% plot(t, input_signal);
% title('Input Signal');
% xlabel('Time (s)');
% ylabel('Amplitude');
% 
% subplot(2,1,2);
% plot(t, left_out);
% title('Left Output Signal with Chorus Effect');
% xlabel('Time (s)');
% ylabel('Amplitude');