clc; clear;
% 定义音频参数
[buffer, Fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\女声.wav');
% 合唱效果参数
num_voices = 5;          % 声部数量
depth = 0.5;             % 合唱深度
lfo_freq = 0.4;          % LFO频率，单位Hz
min_delay = 40/1000;     % 最小延迟，单位毫秒
sweep_width = 40/1000;   % 扫描宽度，单位毫秒            
sampleRate = Fs;         % 采样率
dry_wet_ratio = 1;      % 干/湿混合比例

% 调用 processBlock 函数处理音频
buffer_1 = processBlock(buffer, num_voices, depth, lfo_freq, min_delay, sweep_width, sampleRate, dry_wet_ratio);
audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\女声合唱.wav', buffer_1, Fs);
fprintf('完成！\n');

function buffer_1 = processBlock(buffer, num_voices, depth, lfo_freq, min_delay, sweep_width, sampleRate, dry_wet_ratio)
    num_channels = size(buffer, 2);
    num_samples = size(buffer, 1);
    ph = 0.0;
    interpolation_val=0.0;

    for c = 1:num_channels
        channel_data = buffer(:, c);

        for i = 1:num_samples
             %fprintf('%f   %d\n',channel_data(i),i);
            in_sample = channel_data(i);
            total_out = in_sample ; % 干信号

            for j = 0:num_voices-1
                weight = 1/ (num_voices-1); % 每个声部的权重
                delay_second = min_delay + sweep_width * sin(2 * pi * lfo_freq * (ph + j / num_voices));
                delay_sample = round(delay_second * sampleRate);

                               % 计算相对延迟
                relative_delay = i - delay_sample;
                if relative_delay < 1
                    relative_delay = 1; % 防止索引为0或负数
                elseif relative_delay > num_samples
                    relative_delay = num_samples; % 防止索引超出数组长度
                end
                interpolation_val = channel_data(relative_delay);
                % fprintf('%f   %d\n',interpolation_val,relative_delay);
                total_out_1=total_out;
                total_out = total_out+weight *depth * interpolation_val; 
                total_out=in_sample*(1-dry_wet_ratio)+total_out*dry_wet_ratio;
            end

            ph = ph + 1 / sampleRate;
            if (ph >= 1.0)
                ph = ph - 1.0;
            end
            channel_data(i) = total_out;
        end
        buffer(:, c) = channel_data;
    end
    buffer_1 = buffer;
end