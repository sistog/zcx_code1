clear;clc;
% 读取音频文件
[audioIn, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\女声.wav'); 

% 设置合唱参数
numVoices = 5; % 声部数量
baseDelay = 20/1000; % 基础延迟时间，单位秒
depth = 0.01; % 合唱深度，单位秒
rate = 0.5; % 合唱速率，单位Hz
feedback = 0.5; % 合唱反馈系数

% 初始化合唱信号
chorusSignal = zeros(size(audioIn));

% 生成合唱效果
for v = 1:numVoices
    % 计算每个声部的延迟
    delay = baseDelay + depth * sin(2 * pi * rate * (0:length(audioIn)-1) / fs + (v-1) * (pi/numVoices));
    delaySamples = round(delay * fs);
    
    % 应用延迟
    for i = 1:length(audioIn)
        if i - delaySamples(i) > 0
            chorusSignal(i) = chorusSignal(i) + audioIn(i - delaySamples(i)) * feedback;
        end
    end
end

% 将合唱信号与原始信号混合
audioOut = audioIn + chorusSignal;

audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\女声合唱.wav',audioOut,fs);