clc;clear;close all;
% 设计参数
Fs = 48000; % 采样频率
F0 = [62 125 250 500     1000 2000 4000 8000    13000 16000]; % 中心频率
Q =         [1 2 2 3        2 2 1.5 1.5             1.5 1]; % 品质因数
dBGain =    [24 0 0 0        0 0 0 0                0 -24]; % 中心频率处的增益（分贝）
for i=1:991
end
%初始化
w0=zeros(1,10);
alpha=zeros(1,10);
A=zeros(1,10);
b0=zeros(1,10);
b1=zeros(1,10);
b2=zeros(1,10);
a0=zeros(1,10);
a1=zeros(1,10);
a2=zeros(1,10);

for i=1:10
    w0(i)=2*pi*F0(i)/Fs;
    alpha(i) = sin(w0(i))/(2*Q(i));
    A(i) = 10^(dBGain(i)/40);
end
%小于62HZ
b0(1) = A(1)*( (A(1)+1) - (A(1)-1)*cos(w0(1)) + 2*sqrt(A(1))*alpha(1) );
b1(1) = 2*A(1)*( (A(1)-1) - (A(1)+1)*cos(w0(1)) );
b2(1) = A(1)*( (A(1)+1) - (A(1)-1)*cos(w0(1)) - 2*sqrt(A(1))*alpha(1) );
a0(1) = (A(1)+1) + (A(1)-1)*cos(w0(1)) + 2*sqrt(A(1))*alpha(1);
a1(1) = -2*( (A(1)-1) + (A(1)+1)*cos(w0(1)) );
a2(1) = (A(1)+1) + (A(1)-1)*cos(w0(1)) - 2*sqrt(A(1))*alpha(1);

% 125HZ
b0(2) = 1 + alpha(2) * A(2);
b1(2) = -2 * cos(w0(2));
b2(2) = 1 - alpha(2) * A(2);
a0(2) = 1 + alpha(2) / A(2);
a1(2) = -2 * cos(w0(2));
a2(2) = 1 - alpha(2) / A(2);


% 250HZ
b0(3) = 1 + alpha(3) * A(3);
b1(3) = -2 * cos(w0(3));
b2(3) = 1 - alpha(3) * A(3);
a0(3) = 1 + alpha(3) / A(3);
a1(3) = -2 * cos(w0(3));
a2(3) = 1 - alpha(3) / A(3);

% 500HZ
b0(4) = 1 + alpha(4) * A(4);
b1(4) = -2 * cos(w0(4));
b2(4) = 1 - alpha(4) * A(4);
a0(4) = 1 + alpha(4) / A(4);
a1(4) = -2 * cos(w0(4));
a2(4) = 1 - alpha(4) / A(4);

% 1kHZ
b0(5) = 1 + alpha(5) * A(5);
b1(5) = -2 * cos(w0(5));
b2(5) = 1 - alpha(5) * A(5);
a0(5) = 1 + alpha(5) / A(5);
a1(5) = -2 * cos(w0(5));
a2(5) = 1 - alpha(5) / A(5);

% 2kHZ
b0(6) = 1 + alpha(6) * A(6);
b1(6) = -2 * cos(w0(6));
b2(6) = 1 - alpha(6) * A(6);
a0(6) = 1 + alpha(6) / A(6);
a1(6) = -2 * cos(w0(6));
a2(6) = 1 - alpha(6) / A(6);

% 4kHZ
b0(7) = 1 + alpha(7) * A(7);
b1(7) = -2 * cos(w0(7));
b2(7) = 1 - alpha(7) * A(7);
a0(7) = 1 + alpha(7) / A(7);
a1(7) = -2 * cos(w0(7));
a2(7) = 1 - alpha(7) / A(7);

% 8kHZ
b0(8) = 1 + alpha(8) * A(8);
b1(8) = -2 * cos(w0(8));
b2(8) = 1 - alpha(8) * A(8);
a0(8) = 1 + alpha(8) / A(8);
a1(8) = -2 * cos(w0(8));
a2(8) = 1 - alpha(8) / A(8);

% 13kHZ
b0(9) = 1 + alpha(9) * A(9);
b1(9) = -2 * cos(w0(9));
b2(9) = 1 - alpha(9) * A(9);
a0(9) = 1 + alpha(9) / A(9);
a1(9) = -2 * cos(w0(9));
a2(9) = 1 - alpha(9) / A(9);


%大于16KHZ
% b0(10) = 1 + alpha(10) * A(10);
% b1(10) = -2 * cos(w0(10));
% b2(10) = 1 - alpha(10) * A(10);
% a0(10) = 1 + alpha(10) / A(10);
% a1(10) = -2 * cos(w0(10));
% a2(10) = 1 - alpha(10) / A(10);
b0(10) = A(10)*( (A(10)+1) + (A(10)-1)*cos(w0(10)) + 2*sqrt(A(10))*alpha(10) );
b1(10) = -2*A(10)*( (A(10)-1) + (A(10)+1)*cos(w0(10)) );
b2(10) = A(10)*( (A(10)+1) + (A(10)-1)*cos(w0(10)) - 2*sqrt(A(10))*alpha(10) );
a0(10) = (A(10)+1) - (A(10)-1)*cos(w0(10)) + 2*sqrt(A(10))*alpha(10);
a1(10) = 2*( (A(10)-1) - (A(10)+1)*cos(w0(10)) );
a2(10) = (A(10)+1) - (A(10)-1)*cos(w0(10)) - 2*sqrt(A(10))*alpha(10);
    

num=zeros(1,30);
den=zeros(1,20);
for i=1:10
    num(3*i-2)=b0(i)/a0(i)/2;
    num(3*i-1)=b1(i)/a0(i)/2;
    num(3*i)=b2(i)/a0(i)/2;
    den(2*i-1)=a1(i)/a0(i)/2;
    den(2*i)=a2(i)/a0(i)/2;
end

% 
% % 定义sin的参数
% t = 0:1/Fs:1; % 1秒的时间向量
% f_start = 1; % 起始频率
% f_end = 24000; % 结束频率
% 
% %生成sin
% audioIn = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));
% % % 读取音频文件
% % [audioIn, Fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪.wav');
% 
% audio_temp=audioIn;
% for i=1:10
%     % 确保音频是立体声的
%     if size(audioIn, 2) ~= 2
%         audioOut = filter(num(3*i-2:3*i), den(3*i-2:3*i), audio_temp);
%         audio_temp=audioOut;
%     else
%         % 分离左右声道
%         leftChannel = audio_temp(:, 1);
%         rightChannel = audio_temp(:, 2);
% 
%         % 应用滤波器到每个声道
%         leftOut = filter(num(3*i-2:3*i), den(3*i-2:3*i), leftChannel);
%         rightOut = filter(num(3*i-2:3*i), den(3*i-2:3*i), rightChannel);
% 
%         % 合并处理后的声道
%         audioOut = [leftOut, rightOut];
%         audio_temp=audioOut;
%     end
% end
% 
% % 计算并绘制频谱图
% fsin = fft(audioIn, length(audioIn))*2/length(audioIn);
% f_filtered = fft(audioOut, length(audioOut))*2/length(audioOut);
% % 计算增益（幅度比）
% gain = f_filtered ./ fsin;
% 
% % 将增益转换为分贝（dB）
% gain_dB = 20 * log10(gain);
% 
% % 计算频率轴
% freq = (0:length(audioIn)-1)*(Fs/length(audioIn));
% 
% % 绘制原始信号的频谱
% subplot(3, 1, 1);
% plot(freq(1:length(audioIn)/2), abs(fsin(1:length(audioIn)/2))); % 仅绘制正频率部分
% title('原始audioIn的频谱');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% 
% % 绘制滤波后信号的频谱
% subplot(3, 1, 2);
% plot(freq(1:length(audioOut)/2), abs(f_filtered(1:length(audioOut)/2))); % 仅绘制正频率部分
% title('滤波后信号的频谱');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% 
% % 绘制增益频谱（dB）
% subplot(3, 1, 3);
% plot(freq(1:length(audioIn)/2), gain_dB(1:length(audioIn)/2)); % 仅绘制正频率部分
% title('增益频谱（dB）');
% xlabel('频率 (Hz)');
% ylabel('增益 (dB)');

% % 存处理后的音频到文件
% audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪_4k.wav', audioOut, Fs);