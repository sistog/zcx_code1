clc;clear;close all;
% 设计参数
Fs = 48000; % 采样频率
F0 = 1000/(Fs/2); % 中心频率
Q = 5; % 品质因数
dBGain = 10; % 中心频率处的增益（分贝）

% 设计峰值滤波器
[num, den] = designNotchPeakIIR('Response', 'peak', 'CenterFrequency', F0, 'QualityFactor', Q);

% % 获取分子和分母系数
% [num, den] = tf(d);

% 定义sin的参数
t = 0:1/Fs:1; % 1秒的时间向量
f_start = 1; % 起始频率
f_end = 24000; % 结束频率

% 生成sin
audioIn = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));

% 应用滤波器
audioOut = filter(num, den, audioIn);

% 计算并绘制频谱图
fsin = fft(audioIn)*2/length(audioIn);
f_filtered = fft(audioOut)*2/length(audioOut);

% 计算频率轴
freq = (0:length(audioIn)-1)*(Fs/length(audioIn));

% 绘制频谱图
figure;
subplot(2, 1, 1);
plot(freq(1:length(audioIn)/2), abs(fsin(1:length(audioIn)/2))); % 仅绘制正频率部分
title('原始audioIn的频谱');
xlabel('频率 (Hz)');
ylabel('幅度');

subplot(2, 1, 2);
plot(freq(1:length(audioOut)/2), abs(f_filtered(1:length(audioOut)/2))); % 仅绘制正频率部分
title('滤波后信号的频谱');
xlabel('频率 (Hz)');
ylabel('幅度');
% % 存处理后的音频到文件
% audiowrite('filtered_audio.wav', audioOut, Fs);