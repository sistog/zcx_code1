clc;clear;
N = 16;
m = 16;
fir_coef=[0.139118964429229	-0.220078196469614	0.0967262701507342 -0.899648416565774	0.415415454676123];
q = quantizer('fixed','round','saturate',[N,m]);
fix_fir = quantize(q,fir_coef);
[fix_fir;fir_coef*100];
for index = 1:length(fir_coef)
   % 将整数转换为二进制字符串
    binaryString = num2bin(q, fix_fir(index)); % 第二个参数16表示输出的二进制字符串长度为16
    % 打印二进制字符串
    fprintf("%s",binaryString);
end

