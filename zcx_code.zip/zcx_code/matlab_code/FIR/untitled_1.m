close all;clc;clear;
% n = 4; % 滤波器的阶数，10阶FIR滤波器的阶数为9
% f = [0 0.00083 0.02083 0.0833 0.8333 1]; % 关键频率点，包括通带和阻带的边界
% a = [0 3 1 3 1 0]; % 期望的幅度响应
% b = firpm(n, f, a); % 设计滤波器

% % 设计参数
% n = 10; % 滤波器阶数
% f = [0 0 0.00083 0.02083 0.167 0.8333 1 1]; % 关键频率点
% a = [0 0 1 2 2 1 0 0]; % 期望的幅度响应
% b = firls(n, f, a);

% % 设计参数
% n = 15; % 滤波器的阶数
% f = [0 0.0001 0.00083 0.02083 0.0210 0.1875 0.188 0.8333 0.84 1]; % 频率点
% a = [1 2 2 2 1 1 1 1 0 0]; % 对应的增益
% % 设计滤波器
% b = firpm(n, f, a);

% n =64; % 滤波器阶数
% f = [0 0.0001 0.00083 0.0625 0.063 0.1875 0.188 0.8333 0.84 1]; % 频率点
% m = [1 1 1 1 16 16 1 1 1 1]; % 对应的增益(第2、3、4为低频段系数，第5、6为中频系数，第7、8为高频系数)
% b = fir2(n, f, m); % 设计滤波器

% % 读取音频文件
% [inputAudio, Fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\pianai.wav');
% 
% % 检查输入音频是否为立体声
% numChannels = size(inputAudio, 2);
% if numChannels > 1
%     % 对每个声道分别进行卷积
%     convolvedAudio = zeros(size(inputAudio));
%     for i = 1:numChannels
%         convolvedAudio(:, i) = conv(inputAudio(:, i), b, 'same');
%     end
% else
%     % 单声道音频，直接进行卷积
%     convolvedAudio = conv(inputAudio, b, 'same');
% end
% 
% % 保存卷积后的音频文件
% audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\pianai_1.wav', convolvedAudio, Fs);
% 
% disp('Convolved audio saved as pianai_1.wav');
% 
% % 定义sin的参数
% Fs = 48000; % 采样频率
% t = 0:1/Fs:1; % 1秒的时间向量
% f_start = 1; % 起始频率
% f_end = 24000; % 结束频率
% 
% % 生成sin
% sin = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));
% 
% % 与FIR滤波器抽头系数卷积
% filtered_signal = conv(sin, b);
% filtered_signal = filtered_signal(n+1:length(sin)+n); % 截断以匹配原始信号长度
% 
% % 计算并绘制频谱图
% fsin = fft(sin)*2/length(sin);
% f_filtered = fft(filtered_signal)*2/length(filtered_signal);
% 
% % 计算频率轴
% freq = (0:length(sin)-1)*(Fs/length(sin));
% 
% % 绘制频谱图
% figure;
% subplot(2, 1, 1);
% plot(freq(1:length(sin)/2), abs(fsin(1:length(sin)/2))); % 仅绘制正频率部分
% title('原始sin的频谱');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% 
% subplot(2, 1, 2);
% plot(freq(1:length(filtered_signal)/2), abs(f_filtered(1:length(filtered_signal)/2))); % 仅绘制正频率部分
% title('滤波后信号的频谱');
% xlabel('频率 (Hz)');
% ylabel('幅度');

% 参数设置
f = 1000; % 方波频率，单位为Hz
T = 0.02; % 信号持续时间，单位为秒
dutyCycle = 50; % 占空比，50%表示方波的高电平时间占总周期的一半
Fs=48000;

% 时间向量
t = 0:1/(Fs):T; % 采样频率至少是信号频率的100倍，根据奈奎斯特定理

% 生成方波
y = square(2*pi*f*t, dutyCycle);
N=length(y);
y=y.*30000;
% % 定义sin的参数
% Fs = 48000; % 采样频率
% t = 0:1/Fs:1; % 1秒的时间向量
% f_start = 1; % 起始频率
% f_end = 24000; % 结束频率
% 
% % 生成sin
% y = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));

num=[1    2    1].*(2^14)*0.0039;
den=[ 1    -1.81536865234375    0.830993652343750].*(2^14);

% num1=[0.0350247867675247	-0.0599815493554348	0.0270441266175081];
% den1=[0.5    -0.966141055655680	0.468228419685278];
Out=zeros(1,length(y));
b_x=zeros(1,length(y));
a_y=zeros(1,length(y));
for i=3:length(y)
    Out(i)=(num(1)*y(i)+num(2)*y(i-1)+num(3)*y(i-2)-den(2)*Out(i-1)-den(3)*Out(i-2))/(2^14);
    b_x(i)=(num(1)*y(i)+num(2)*y(i-1)+num(3)*y(i-2))/(2^14);
    a_y(i)=(den(2)*Out(i-1)+den(3)*Out(i-2))/(2^14);
end
Out(1)=(num(1)*y(1))/(2^14);
Out(2)=(num(1)*y(2)+num(2)*y(2-1)-den(2)*Out(2-1))/(2^14);
 % Out = filter(num1, den1, Out1);
figure;
% 绘制方波
plot(t, y);
xlabel('时间 (s)');
ylabel('幅度');
title('方波信号');
hold on;
plot(t, Out);
xlabel('时间 (s)');
ylabel('幅度');
title('滤波信号');

% 计算并绘制频谱图
fsin = fft(y, length(y))*2/length(y);
f_filtered = fft(Out, length(Out))*2/length(Out);
% 计算增益（幅度比）
gain = f_filtered ./ fsin;

% 将增益转换为分贝（dB）
gain_dB = 20 * log10(gain);

% 计算频率轴
freq = (0:length(y)-1)*(Fs/length(y));
figure;
% 绘制原始信号的频谱
subplot(3, 1, 1);
plot(freq(1:length(y)/2), abs(fsin(1:length(y)/2))); % 仅绘制正频率部分
title('原始audioIn的频谱');
xlabel('频率 (Hz)');
ylabel('幅度');

% 绘制滤波后信号的频谱
subplot(3, 1, 2);
plot(freq(1:length(Out)/2), abs(f_filtered(1:length(Out)/2))); % 仅绘制正频率部分
title('滤波后信号的频谱');
xlabel('频率 (Hz)');
ylabel('幅度');

% 绘制增益频谱（dB）
subplot(3, 1, 3);
plot(freq(1:length(y)/2), gain_dB(1:length(y)/2)); % 仅绘制正频率部分
title('增益频谱（dB）');
xlabel('频率 (Hz)');
ylabel('增益 (dB)');