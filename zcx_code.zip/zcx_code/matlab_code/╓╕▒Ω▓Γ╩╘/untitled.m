clear;clc;% 读取音频文件
[audioData1, Fs1] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\降噪钱.wav'); % 替换为你的音频文件路径
[audioData2, Fs2] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\降噪后.wav'); % 替换为你的音频文件路径
noise=audioData1-audioData2(1,:);
% 如果音频是立体声，将两个声道的信号合并
if size(audioData1, 2) > 1
    audioData1 = audioData1(:, 1) + audioData1(:, 2); % 合并两个声道
end

% 计算信号幅度的平方
audioPower1 = audioData1.^2;

% 计算平均功率
averagePower1 = mean(audioPower1(:)); % 计算所有样本的平均功率

if size(noise, 2) > 1
    noise = noise(:, 1) + noise(:, 2); % 合并两个声道
end

% 计算信号幅度的平方
audioPower2 = noise.^2;

% 计算平均功率
averagePower2 = mean(audioPower2(:)); % 计算所有样本的平均功率

% 计算总体信噪比（OSNR）
OSNR1 = 10 * log10(averagePower1 / averagePower2);


% 显示平均功率
disp(['Average Power of the Audio Signal: ', num2str(OSNR1)]);

