clear;clc;close all;
% %扫频信号
% % 定义sin的参数
% fs=48000;
% t = 0:1/fs:1; % 1秒的时间向量
% f_start = 1; % 起始频率
% f_end = 24000; % 结束频率
% %生成sin
% sweepSignal = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));
load('num_save.mat', 'num_save');
load('den_save.mat','den_save');
% 读取音乐文件
[sweepSignal, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段.wav'); 
% 检查音频数据的维度
[numSamples, numChannels] = size(sweepSignal);

% 设置片段长度（例如，500毫秒）
segmentLength = 10; % 毫秒
segmentLengthSamples = round(segmentLength * fs / 1000);
% segmentLengthSamples =48;

% 初始化用于存储处理后音频的数组
processedAudio = [];

% 计算需要处理的片段数量
numSegments = ceil(length(sweepSignal) / segmentLengthSamples);

% 设计参数
k = 0.5; % 反馈系数
n = 6; % 滤波器阶数
dryWet=2;
LFO_fre=1;%震荡频率
i=1;
jump=LFO_fre*segmentLength;%步长

% 模拟环绕声效果并分片段处理
for seg = 1:numSegments
    % 获取当前片段
    startIdx = (seg - 1) * segmentLengthSamples + 1;
    endIdx = min(startIdx + segmentLengthSamples - 1, length(sweepSignal));
    segment = sweepSignal(startIdx:endIdx, :);

    % 对当前片段应用效果
    if(i<=1000)
        num=num_save((i-1)*(n+1)+1:i*(n+1));
        den=den_save((i-1)*(n+1)+1:i*(n+1));
        i=i+jump;
    else
        i=1;
        num=num_save((i-1)*(n+1)+1:i*(n+1));
        den=den_save((i-1)*(n+1)+1:i*(n+1));
    end
    b_ap=num;
    a_ap=den-num.*k;

    stereoSignal=segment;
    % 应用全通滤波器
    stereoSignal(:,1) = filter(b_ap, a_ap, stereoSignal(:,1));
    stereoSignal(:,2) = filter(b_ap, a_ap, stereoSignal(:,2));
    outputSignal =(stereoSignal+segment)./2;
    outputSignal = dryWet/(dryWet+1) * outputSignal + 1/(dryWet+1) * segment;

        % 将处理后的片段追加到数组中
        processedAudio = [processedAudio; outputSignal];

        % 如果已经处理了足够的片段，就停止处理
        if size(processedAudio, 1) >= length(sweepSignal)
            break;
        end
end
% 
% Fs = 48000;  % 采样频率，单位Hz
% fc = 15000;   % 截止频率，单位Hz
% n = 4;       % 滤波器的阶数
% Wn = fc / (Fs/2);
% [b, a] = butter(n, Wn, 'low');
% processedAudio=filter(b,a,processedAudio);
% 保存处理后的音频为一个新的文件
audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段相位器.wav', processedAudio, fs);

% 
% [sweepSignal, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段.wav'); 
% [processedAudio, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段相位器.wav'); 
% 计算FFT
% n = length(processedAudio); % 信号长度
% f = (0:n/2)*(fs/n); % 单边频率向量
% 
% % 计算FFT的单边频谱
% inputFFT = fft(sweepSignal); % 输入信号的FFT
% outputFFT = fft(processedAudio); % 输出信号的FFT
% 
% % 取FFT的一半（单边频谱）
% inputMagnitude = abs(inputFFT(1:n/2+1)/n); % 输入信号的单边幅值
% outputMagnitude = abs(outputFFT(1:n/2+1)/n); % 输出信号的单边幅值
% 
% 
% % 绘制单边幅频响应图和相位响应图
% figure;
% subplot(3,1,1);
% plot(f, inputMagnitude);
% title('输入信号的单边幅频响应');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% xlim([0 4000]);
% 
% 
% subplot(3,1,2);
% plot(f, outputMagnitude);
% title('输出信号的单边幅频响应');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% xlim([0 4000]);
% 
% % 计算增益
% gain = 20*log10(outputMagnitude ./ inputMagnitude); % 幅频增益（dB）
% subplot(3,1,3);
% plot(f, gain);
% title('单边幅频增益图');
% xlabel('频率 (Hz)');
% ylabel('增益 (dB)');
% 
% t=0:1/fs:length(sweepSignal(:,1))/fs-1/fs;
% figure;
% plot(t,sweepSignal(:,1));
% title('原信号时域图');
% 
% t=0:1/fs:length(processedAudio(:,1))/fs-1/fs;
% figure;
% plot(t,processedAudio(:,1));
% title('处理信号信号时域图');


% 
% % 计算FFT
% n = length(outputSignal); % 信号长度
% f = (0:n/2)*(fs/n); % 单边频率向量
% 
% % 计算FFT的单边频谱
% inputFFT = fft(sweepSignal); % 输入信号的FFT
% outputFFT = fft(outputSignal); % 输出信号的FFT
% 
% % 取FFT的一半（单边频谱）
% inputMagnitude = abs(inputFFT(1:n/2+1)/n); % 输入信号的单边幅值
% outputMagnitude = abs(outputFFT(1:n/2+1)/n); % 输出信号的单边幅值
% 
% % 计算增益
% gain = 20*log10(outputMagnitude ./ inputMagnitude); % 幅频增益（dB）
% 
% % 计算FFT的单边频谱的相位
% inputPhase = angle(inputFFT(1:n/2+1)); % 输入信号的单边相位
% outputPhase = angle(outputFFT(1:n/2+1)); % 输出信号的单边相位
% 
% % 计算相位差
% phaseDifference = outputPhase - inputPhase;
% 
% % 绘制单边幅频响应图和相位响应图
% figure;
% subplot(3,1,1);
% plot(f, inputMagnitude);
% title('输入信号的单边幅频响应');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% 
% subplot(3,1,2);
% plot(f, gain);
% title('单边幅频增益图');
% xlabel('频率 (Hz)');
% ylabel('增益 (dB)');
% 
% subplot(3,1,3);
% plot(f, phaseDifference * (180/pi)); % 将相位差转换为度
% title('单边相位响应图');
% xlabel('频率 (Hz)');
% ylabel('相位差 (度)');