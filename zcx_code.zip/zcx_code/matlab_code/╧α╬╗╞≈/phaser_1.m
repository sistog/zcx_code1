 close all;clear;clc;
% % %扫频信号
% % % 定义sin的参数
% % fs=48000;
% % t = 0:1/fs:1; % 1秒的时间向量
% % f_start = 1; % 起始频率
% % f_end = 24000; % 结束频率
% % %生成sin
% % audioIn = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));
% % audioIn=audioIn';
% % audiotemp=audioIn;
% 
% [audioIn,fs]=audioread('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段.wav');
% audiotemp=audioIn;
% 
% sampleRate = fs; % 采样率
% stages = 1; % 全通滤波器的数量
% dryWet = 1; % 干/湿比
% lfoFreq = 0.0001; % LFO的调制频率
% lfoStartPhase = 0.0; % LFO的起始相位
% depth =1 ; % LFO的调制深度
% feedback = 100/100; % 反馈量
% outputGain = -6.0; % 输出增益（分贝）
% 
% 
%     % 初始化输出信号
%     outputSignal = zeros(size(audioIn));
% 
%     % 初始化全通滤波器的延迟线
%     delayTimes = (1:stages) * 10; % 每个阶段的延迟时间，单位为样本数
%     delayLinesLeft = cell(1, stages);
%     delayLinesRight = cell(1, stages);
%     for i = 1:stages
%         delayLinesLeft{i} = zeros(1, delayTimes(i));
%         delayLinesRight{i} = zeros(1, delayTimes(i));
%     end
% 
%     % 处理输入信号的每个样本
%     for n = 1:length(audioIn)
%         % 计算LFO调制的反馈量
%         lfoValueLeft = depth * sin(2 * pi * lfoFreq * n / sampleRate + lfoStartPhase);
%         modulatedFeedbackLeft = feedback * (1 + lfoValueLeft);
%         lfoValueRight = depth *sin(2 * pi * lfoFreq * n / sampleRate + lfoStartPhase);
%         modulatedFeedbackRight = feedback * (1 + lfoValueRight);
% 
%         % 通过全通滤波器处理左声道信号
%         for i = 1:stages
%             % 读取延迟线的输出
%             delayedOutputLeft = delayLinesLeft{i}(end);
%             delayedOutputRight = delayLinesRight{i}(end);
% 
%             % 计算当前阶段的输出
%             currentOutputLeft = modulatedFeedbackLeft * delayedOutputLeft + audioIn(n, 1)-delayedOutputLeft;
%             currentOutputRight = modulatedFeedbackRight * delayedOutputRight + audioIn(n, 2)-delayedOutputRight;
% 
%             % 更新延迟线
%             delayLinesLeft{i}(1:end-1) = delayLinesLeft{i}(2:end);
%             delayLinesLeft{i}(end) = currentOutputLeft;
%             delayLinesRight{i}(1:end-1) = delayLinesRight{i}(2:end);
%             delayLinesRight{i}(end) = currentOutputRight;
% 
%             % 更新输入信号为当前阶段的输出
%             audioIn(n, 1) = currentOutputLeft;
%             audioIn(n, 2) = currentOutputRight;
%         end
% 
%         % 累加所有阶段的输出
%         outputSignal(n, 1) = sum(cell2mat(delayLinesLeft));
%         outputSignal(n, 2) = sum(cell2mat(delayLinesRight));
%     end
% 
%     % 应用干/湿比
%     outputSignal=outputSignal/stages;
%     outputSignal = dryWet/(dryWet+1) * outputSignal + 1/(dryWet+1) * audioIn;
% 
%     % 应用输出增益
%     outputSignal = outputSignal * 10^(outputGain / 20);
% 
%     % 输出信号
%     audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆相位器.wav',outputSignal,sampleRate);
% 
% 
% [audioOut,fs]=audioread('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆相位器.wav');
% 
% audioIn=audiotemp;
% 
% % 计算并绘制频谱图
% fsin = fft(audioIn, length(audioIn))*2/length(audioIn);
% f_filtered = fft(audioOut, length(audioOut))*2/length(audioOut);
% % 计算增益（幅度比）
% gain = f_filtered ./ fsin;
% 
% % 将增益转换为分贝（dB）
% gain_dB = 20 * log10(gain);
% 
% % 计算频率轴
% freq = (0:length(audioIn)-1)*(fs/length(audioIn));
% 
% figure;
% % 绘制原始信号的频谱
% subplot(3, 1, 1);
% plot(freq(1:length(audioIn)/2), abs(fsin(1:length(audioIn)/2))); % 仅绘制正频率部分
% title('原始audioIn的频谱');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% 
% % 绘制滤波后信号的频谱
% subplot(3, 1, 2);
% plot(freq(1:length(audioOut)/2), abs(f_filtered(1:length(audioOut)/2))); % 仅绘制正频率部分
% title('处理后信号的频谱'); 
% xlabel('频率 (Hz)');
% ylabel('幅度');
% 
% % 绘制增益频谱（dB）
% subplot(3, 1, 3);
% plot(freq(1:length(audioIn)/2), gain_dB(1:length(audioIn)/2)); % 仅绘制正频率部分
% title('增益频谱（dB）');
% xlabel('频率 (Hz)');
% ylabel('增益 (dB)');
% zoom xon;

% 参数设置
N = 1000; % 采样频率
t = 0:1/N:1; % 时间向量，生成一个周期的波形

% 生成三角波
% 三角波可以通过取绝对值然后减去0.5再乘以2得到
triangle_wave = (2 * (sawtooth(2*pi*t, 0.5) - 0.5)+3)/4;
triangle_wave_1=[triangle_wave(1:500) triangle_wave(500:-1:1)];
triangle_wave_2=[triangle_wave(2:501) triangle_wave(501:-1:2)];
% 绘制三角波
plot(t, triangle_wave);
xlabel('Time (s)');
ylabel('Amplitude');
title('LFO Triangle Wave (One Period)');
grid on;