clear;clc;close all;%%
%%计算滤波器系数
% %扫频信号
% % 定义sin的参数
% fs=48000;
% t = 0:1/fs:1; % 1秒的时间向量
% f_start = 1; % 起始频率
% f_end = 24000; % 结束频率
% %生成sin
% sweepSignal = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));

Fs = 48000; % 采样频率
Fs2 = Fs / 2; % Nyquist 频率


% % 设置片段长度（例如，500毫秒）
% segmentLength = 20; % 毫秒
% segmentLengthSamples = round(segmentLength * fs / 1000);
% 
% % 初始化用于存储处理后音频的数组
% processedAudio = [];
% 
% % 计算需要处理的片段数量
% numSegments = ceil(length(sweepSignal) / segmentLengthSamples);
% %一秒需要处理的片段数
% N = 1000/segmentLength;
% % 生成 LFO 信号
% N=1000;
% t = 0:0.25/N:0.25; % 归一化频率
% LFO_signal = LFO_amp * sin(2 * pi * t);
% LFO_signal = round(LFO_signal, 20);
% 参数设置
N = 1000; % 采样频率
t = 0:1/N:1; % 时间向量，生成一个周期的波形

% 生成三角波
% 三角波可以通过取绝对值然后减去0.5再乘以2得到
LFO_signal = (2 * (sawtooth(2*pi*t, 0.5) - 0.5)+3)/4;
LFO_signal = round(LFO_signal, 6);
Fp1=[LFO_signal(1:(N/2)) LFO_signal((N/2):-1:1)];
Fp2=[LFO_signal(2:(N/2+1)) LFO_signal((N/2+1):-1:2)];


% 设计参数
k = 0.5; % 反馈系数
n = 6; % 滤波器阶数
% i=1;
num_save=zeros(1,N*(n+1));
den_save=zeros(1,N*(n+1));
% 模拟环绕声效果并分片段处理
for i=1:N

    fprintf('处理%d\n', i);
        edges = [Fp1(i) Fp2(i)]; % 带边缘频率
        f = Fp1(i):1/10000000:Fp2(i); % 频率点，包括0和Nyquist频率
        a = ones(size(f)); % 通带内群延迟为1
        a(f < edges(1) | f > edges(2)) = 0.1;
        w = ones(size(f));
        p = [8 64];

    % 设计全通滤波器
    [num, den] = iirgrpdelay(n, f, edges, a,w,0.8,p);
    num_save(((i-1)*(n+1)+1):(i*(n+1)))=num(1:(n+1));
    den_save(((i-1)*(n+1)+1):(i*(n+1)))=den(1:(n+1)); 
    % b_ap=num;
    % a_ap=den-num.*k;
    
end
% for j=1:N/2
%     num_save(((N/2-i)*7+1):((N/2+1-i)*7))=;
% 
% 
% end
save("num_save.mat",'num_save');
save("den_save.mat",'den_save');

% 
% % 计算FFT
% n = length(outputSignal); % 信号长度
% f = (0:n/2)*(fs/n); % 单边频率向量
% 
% % 计算FFT的单边频谱
% inputFFT = fft(sweepSignal); % 输入信号的FFT
% outputFFT = fft(outputSignal); % 输出信号的FFT
% 
% % 取FFT的一半（单边频谱）
% inputMagnitude = abs(inputFFT(1:n/2+1)/n); % 输入信号的单边幅值
% outputMagnitude = abs(outputFFT(1:n/2+1)/n); % 输出信号的单边幅值
% 
% % 计算增益
% gain = 20*log10(outputMagnitude ./ inputMagnitude); % 幅频增益（dB）
% 
% % 计算FFT的单边频谱的相位
% inputPhase = angle(inputFFT(1:n/2+1)); % 输入信号的单边相位
% outputPhase = angle(outputFFT(1:n/2+1)); % 输出信号的单边相位
% 
% % 计算相位差
% phaseDifference = outputPhase - inputPhase;
% 
% % 绘制单边幅频响应图和相位响应图
% figure;
% subplot(3,1,1);
% plot(f, inputMagnitude);
% title('输入信号的单边幅频响应');
% xlabel('频率 (Hz)');
% ylabel('幅度');
% 
% subplot(3,1,2);
% plot(f, gain);
% title('单边幅频增益图');
% xlabel('频率 (Hz)');
% ylabel('增益 (dB)');
% 
% subplot(3,1,3);
% plot(f, phaseDifference * (180/pi)); % 将相位差转换为度
% title('单边相位响应图');
% xlabel('频率 (Hz)');
% ylabel('相位差 (度)');