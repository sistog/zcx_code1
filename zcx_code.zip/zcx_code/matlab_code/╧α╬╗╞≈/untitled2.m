clear; clc;close all;
 Fs = 48000; % 采样频率
Fs2 = Fs / 2; % Nyquist 频率

% 通带频率
Fp1 = 0/24000; % 通带下限归一化
Fp2 = 0.833; % 通带上限归一化

% 设计参数
n = 10; % 滤波器阶数，可以根据需要调整
f = Fp1:0.00001:Fp2; % 频率点，包括0和Nyquist频率
edges = [Fp1 Fp2]; % 带边缘频率
a = ones(size(f)).*1; % 通带内群延迟为1
w = ones(size(f));
p = [4 64];
% 设计全通滤波器
[num, den] = iirgrpdelay(n, f, edges, a,w,0.1,p);


% 计算和绘制滤波器的频率响应
[H, w] = freqz(num, den, 102000, Fs);
figure;
subplot(2, 1, 1);
plot(w, 20*log10(abs(H)));
title('全通滤波器的幅度响应');
xlabel('频率 (Hz)');
ylabel('幅度 (dB)');

angle1=angle(H);
subplot(2, 1, 2);
plot(w, unwrap(angle1) * (180/pi));
title('全通滤波器的相位响应');
xlabel('频率 (Hz)');
ylabel('相位 (度)');