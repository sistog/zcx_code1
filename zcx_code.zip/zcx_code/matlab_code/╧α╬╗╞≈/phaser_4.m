clear; clc;close all;
 Fs = 48000; % 采样频率
Fs2 = Fs / 2; % Nyquist 频率

%扫频信号
% 定义sin的参数
fs=48000;
t = 0:1/fs:1; % 1秒的时间向量
f_start = 1; % 起始频率
f_end = 24000; % 结束频率
%生成sin
sweepSignal = sin(2*pi*(f_start*t + (f_end - f_start)/2*t.^2));
% [sweepSignal, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\加州旅馆片段.wav'); 

% 通带频率
Fp1 = 0.000; % 通带下限归一化
Fp2 = 0.004; % 通带上限归一化

% 设计参数
n = 10; % 滤波器阶数，可以根据需要调整
f = Fp1:0.0000001:Fp2; % 频率点，包括0和Nyquist频率
edges = [Fp1 Fp2]; % 带边缘频率
a = ones(size(f)).*1; % 通带内群延迟为1
w = ones(size(f));
p = [2 128];
k=0.0;
dryWet=2;
% 设计全通滤波器
[num, den] = iirgrpdelay(n, f, edges, a,w,0.9,p);
b_ap=num;
a_ap=den-num.*k;


load('num_save.mat', 'num_save');
load('den_save.mat','den_save');
stereoSignal=sweepSignal;
% 应用全通滤波器
j=100;
n=6;
k=0.1;
stereoSignal = filter(num_save((j-1)*(n+1)+1:j*(n+1)), den_save((j-1)*(n+1)+1:j*(n+1))-num_save((j-1)*(n+1)+1:j*(n+1)).*k, stereoSignal);
outputSignal =(stereoSignal+sweepSignal)./2;

% % 应用全通滤波器
% stereoSignal = filter(num, den, stereoSignal);
% outputSignal =(stereoSignal+sweepSignal)./2;
% outputSignal = dryWet/(dryWet+1) * outputSignal + 1/(dryWet+1) * sweepSignal;

t=0:1/fs:length(sweepSignal(:,1))/fs-1/fs;
figure;
plot(t,sweepSignal(:,1).*32678);
title('原信号时域图');
xlim([0 0.05]);
hold on;

t=0:1/fs:length(outputSignal(:,1))/fs-1/fs;
plot(t,outputSignal(:,1).*32678);
title('处理信号信号时域图');
xlim([0 0.05]);
zoom xon;



% 计算FFT
n = length(outputSignal); % 信号长度
f = (0:n/2)*(fs/n); % 单边频率向量

% 计算FFT的单边频谱
inputFFT = fft(sweepSignal); % 输入信号的FFT
outputFFT = fft(outputSignal); % 输出信号的FFT

% 取FFT的一半（单边频谱）
inputMagnitude = abs(inputFFT(1:n/2+1)/n); % 输入信号的单边幅值
outputMagnitude = abs(outputFFT(1:n/2+1)/n); % 输出信号的单边幅值

% 计算增益
gain = 20*log10(outputMagnitude ./ inputMagnitude); % 幅频增益（dB）

% 计算FFT的单边频谱的相位
inputPhase = angle(inputFFT(1:n/2+1)); % 输入信号的单边相位
outputPhase = angle(outputFFT(1:n/2+1)); % 输出信号的单边相位

% 计算相位差
phaseDifference = outputPhase - inputPhase;

% 绘制单边幅频响应图和相位响应图
figure;
subplot(3,1,1);
plot(f, inputMagnitude);
title('输入信号的单边幅频响应');
xlabel('频率 (Hz)');
ylabel('幅度');

subplot(3,1,2);
plot(f, gain);
title('单边幅频增益图');
xlabel('频率 (Hz)');
ylabel('增益 (dB)');

subplot(3,1,3);
plot(f, phaseDifference * (180/pi)); % 将相位差转换为度
title('单边相位响应图');
xlabel('频率 (Hz)');
ylabel('相位差 (度)');

% % 计算和绘制滤波器的频率响应
% [H, w] = freqz(num, den, 102000, Fs);
% figure;
% subplot(2, 1, 1);
% plot(w, 20*log10(abs(H)));
% title('全通滤波器的幅度响应');
% xlabel('频率 (Hz)');
% ylabel('幅度 (dB)');
% 
% angle1=angle(H);
% subplot(2, 1, 2);
% plot(w, unwrap(angle1) * (180/pi));
% title('全通滤波器的相位响应');
% xlabel('频率 (Hz)');
% ylabel('相位 (度)');