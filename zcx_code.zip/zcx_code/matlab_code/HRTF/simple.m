clear;clc;
% 读取双声道立体声音乐文件
[audio, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪片段.wav'); 
% 检查音频数据的维度
[numSamples, numChannels] = size(audio);

% 设置片段长度（例如，500毫秒）
fre=0.5;
segmentLength = 1000/(fre*360); % 毫秒
segmentLengthSamples = round(segmentLength * fs / 1000);

% 初始化用于存储处理后音频的数组
processedAudio = [];

% 计算需要处理的片段数量
numSegments = ceil(length(audio) / segmentLengthSamples);

% 模拟环绕声效果并分片段处理
for seg = 1:numSegments
    % 获取当前片段
    startIdx = (seg - 1) * segmentLengthSamples + 1;
    endIdx = min(startIdx + segmentLengthSamples - 1, length(audio));
    segment = audio(startIdx:endIdx, :);

    % 对当前片段应用环绕声效果
        angle=seg;
        % 根据角度计算左右声道的增益
        leftGain = cos(deg2rad(angle));
        rightGain = sin(deg2rad(angle));
        fprintf('%f   %f  %d\n',leftGain,rightGain,angle);

        % 应用增益到当前片段
        stereoSignal = segment;
        stereoSignal(:,1) = stereoSignal(:,1) .* leftGain;
        stereoSignal(:,2) = stereoSignal(:,2) .* rightGain;

        % 将处理后的片段追加到数组中
        processedAudio = [processedAudio; stereoSignal];

        % 如果已经处理了足够的片段，就停止处理
        if size(processedAudio, 1) >= length(audio)
            break;
        end
end
jiao=cos(1);
fprintf('%f',jiao);
% 保存处理后的音频为一个新的文件
audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪3D.wav', processedAudio, fs);