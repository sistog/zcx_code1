clear;clc;
% 读取测试音频文件
[audio_test, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪.wav');

% 提取 MFCC 特征
% 注意：确保窗口长度、重叠长度和 FFT 长度与您的音频信号兼容
winLength = 25; % 窗口长度（毫秒）
overlapLength = 20; % 重叠长度（毫秒）
nCoeffs = 13; % MFCC 系数的数量
nFFT = 512; % FFT 长度

% 将窗口长度和重叠长度转换为样本数
winLengthSamples = round(winLength * fs / 1000);
overlapLengthSamples = round(overlapLength * fs / 1000);

% 提取 MFCC 特征
newMFCCFeatures = mfcc(audio_test, fs, 'WindowLength', winLengthSamples, ...
    'OverlapLength', overlapLengthSamples, 'NumCoeffs', nCoeffs);

% 将分离的 MFCC 特征转换回时域音频信号
% 注意：istft 需要的输入是复数矩阵，其中每列代表一个 STFT 窗口
% 这里假设 newMFCCFeatures 是一个矩阵，每行是一个时间帧的特征
% 如果 newMFCCFeatures 不是复数矩阵，需要先将其转换为复数矩阵
% 例如，使用 mean(newMFCCFeatures) + 1i*std(newMFCCFeatures) 来生成随机相位
voiceAudio = istft(newMFCCFeatures, 'FFTLength', nFFT);

voiceAudio = real(voiceAudio);
% 保存分离后的音频
audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪MFCC.wav', voiceAudio, fs);