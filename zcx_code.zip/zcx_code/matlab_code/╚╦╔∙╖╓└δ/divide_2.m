% 假设有两个文件夹：'voiceFolder' 和 'bgFolder'，分别存放人声和背景音乐

% 定义文件夹路径
voiceFolder = 'path_to_voice_folder';
bgFolder = 'path_to_background_music_folder';
testFolder='';
% 获取文件夹内所有音频文件的列表
voiceFiles = dir(fullfile(voiceFolder, '*.wav'));
bgFiles = dir(fullfile(bgFolder, '*.wav'));

% 初始化存储特征的变量
voiceFeatures = [];
bgFeatures = [];

% 提取人声特征
for i = 1:length(voiceFiles)
    % 读取音频文件
    [audioIn, fs] = audioread(fullfile(voiceFolder, voiceFiles(i).name));
    
    % 提取MFCC特征
    mfccFeat = mfcc(audioIn, 25, 20, 13, fs);
    
    % 将特征添加到人声特征矩阵中
    voiceFeatures = [voiceFeatures; mfccFeat];
end

% 提取背景音乐特征
for i = 1:length(bgFiles)
    % 读取音频文件
    [audioIn, fs] = audioread(fullfile(bgFolder, bgFiles(i).name));
    
    % 提取MFCC特征
    mfccFeat = mfcc(audioIn, 25, 20, 13, fs);
    
    % 将特征添加到背景音乐特征矩阵中
    bgFeatures = [bgFeatures; mfccFeat];
end

% 训练GMM模型
numComponents = 2; % 高斯分量的数量
voiceGMM = fitgmdist(voiceFeatures, numComponents, 'CovarianceType', 'diagonal', 'Options', statset('MaxIter', 500));
bgGMM = fitgmdist(bgFeatures, numComponents, 'CovarianceType', 'diagonal', 'Options', statset('MaxIter', 500));


% 使用GMM对新的音频数据进行分类
[audio_test, fs] = audioread(fullfile(testFolder, testFolder(i).name));
newMFCCFeatures = mfcc(audio_test, 25, 20, 13, fs); % 新音频数据的MFCC特征
voiceProb=posteriorProb(voiceGMM, newMFCCFeatures);
bgProb = posteriorProb(bgGMM, newMFCCFeatures);

% 根据后验概率分离人声和背景音乐
separatedVoice = newMFCCFeatures(voiceProb > bgProb, :);
separatedBG = newMFCCFeatures(voiceProb <= bgProb, :);

% 将分离的MFCC特征转换回时域音频信号
voiceAudio = istft(separatedVoice);
bgAudio = istft(separatedBG);

% 保存或播放分离后的音频
audiowrite('separated_voice.wav', voiceAudio, fs);
audiowrite('separated_background_music.wav', bgAudio, fs);