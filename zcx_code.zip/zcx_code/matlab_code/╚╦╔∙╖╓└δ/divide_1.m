clear;clc;
% 读取双声道立体声音乐文件
[audio, fs] = audioread('C:\Users\zheng\Desktop\FPGA_gowim\pianai.wav'); 
N=length(audio);
delay=10/48000;
deter1=zeros(N,1);
deter=zeros(N,1);
deter=audio(:,1)-audio(:,2);
processedAudio=[deter,deter];
for i=1:N-delay*fs
    deter1(i)=audio(i+delay*fs,1)-audio(i,2);
end
peoAudio=[deter1,deter1];


num=zeros(1,50*25);
dB=[0 0 0      0 -0 -0     -0 0 0 0];%增益
for index=0:24
    % 设计参数
    Fs = 48000; % 采样频率
    F0 = [62 125 250 500     1000 2000 4000 8000    13000 16000]; % 中心频率
    Q =         [1 2 2 3        2 2 1.5 1.5             1.5 1]; % 品质因数
    dBGain =    [-12 -12 -12 -12        -12 -12 -12 -12                -12 -12]; % 中心频率处的增益（分贝）
    for i=1:10
        dBGain(i)=dBGain(i)+index;
    end
    %初始化
    w0=zeros(1,10);
    alpha=zeros(1,10);
    A=zeros(1,10);
    b0=zeros(1,10);
    b1=zeros(1,10);
    b2=zeros(1,10);
    a0=zeros(1,10);
    a1=zeros(1,10);
    a2=zeros(1,10);
    
    for i=1:10
        w0(i)=2*pi*F0(i)/Fs;
        alpha(i) = sin(w0(i))/(2*Q(i));
        A(i) = 10^(dBGain(i)/40);
    end
    %小于31HZ
    b0(1) = A(1)*( (A(1)+1) - (A(1)-1)*cos(w0(1)) + 2*sqrt(A(1))*alpha(1) );
    b1(1) = 2*A(1)*( (A(1)-1) - (A(1)+1)*cos(w0(1)) );
    b2(1) = A(1)*( (A(1)+1) - (A(1)-1)*cos(w0(1)) - 2*sqrt(A(1))*alpha(1) );
    a0(1) = (A(1)+1) + (A(1)-1)*cos(w0(1)) + 2*sqrt(A(1))*alpha(1);
    a1(1) = -2*( (A(1)-1) + (A(1)+1)*cos(w0(1)) );
    a2(1) = (A(1)+1) + (A(1)-1)*cos(w0(1)) - 2*sqrt(A(1))*alpha(1);
    
    % 62HZ
    b0(2) = 1 + alpha(2) * A(2);
    b1(2) = -2 * cos(w0(2));
    b2(2) = 1 - alpha(2) * A(2);
    a0(2) = 1 + alpha(2) / A(2);
    a1(2) = -2 * cos(w0(2));
    a2(2) = 1 - alpha(2) / A(2);
    
    
    % 125HZ
    b0(3) = 1 + alpha(3) * A(3);
    b1(3) = -2 * cos(w0(3));
    b2(3) = 1 - alpha(3) * A(3);
    a0(3) = 1 + alpha(3) / A(3);
    a1(3) = -2 * cos(w0(3));
    a2(3) = 1 - alpha(3) / A(3);
    
    % 250HZ
    b0(4) = 1 + alpha(4) * A(4);
    b1(4) = -2 * cos(w0(4));
    b2(4) = 1 - alpha(4) * A(4);
    a0(4) = 1 + alpha(4) / A(4);
    a1(4) = -2 * cos(w0(4));
    a2(4) = 1 - alpha(4) / A(4);
    
    % 500HZ
    b0(5) = 1 + alpha(5) * A(5);
    b1(5) = -2 * cos(w0(5));
    b2(5) = 1 - alpha(5) * A(5);
    a0(5) = 1 + alpha(5) / A(5);
    a1(5) = -2 * cos(w0(5));
    a2(5) = 1 - alpha(5) / A(5);
    
    % 1kHZ
    b0(6) = 1 + alpha(6) * A(6);
    b1(6) = -2 * cos(w0(6));
    b2(6) = 1 - alpha(6) * A(6);
    a0(6) = 1 + alpha(6) / A(6);
    a1(6) = -2 * cos(w0(6));
    a2(6) = 1 - alpha(6) / A(6);
    
    % 2kHZ
    b0(7) = 1 + alpha(7) * A(7);
    b1(7) = -2 * cos(w0(7));
    b2(7) = 1 - alpha(7) * A(7);
    a0(7) = 1 + alpha(7) / A(7);
    a1(7) = -2 * cos(w0(7));
    a2(7) = 1 - alpha(7) / A(7);
    
    % 4kHZ
    b0(8) = 1 + alpha(8) * A(8);
    b1(8) = -2 * cos(w0(8));
    b2(8) = 1 - alpha(8) * A(8);
    a0(8) = 1 + alpha(8) / A(8);
    a1(8) = -2 * cos(w0(8));
    a2(8) = 1 - alpha(8) / A(8);
    
    % 8kHZ
    b0(9) = 1 + alpha(9) * A(9);
    b1(9) = -2 * cos(w0(9));
    b2(9) = 1 - alpha(9) * A(9);
    a0(9) = 1 + alpha(9) / A(9);
    a1(9) = -2 * cos(w0(9));
    a2(9) = 1 - alpha(9) / A(9);
    
    
    %大于16KHZ
    % b0(10) = 1 + alpha(10) * A(10);
    % b1(10) = -2 * cos(w0(10));
    % b2(10) = 1 - alpha(10) * A(10);
    % a0(10) = 1 + alpha(10) / A(10);
    % a1(10) = -2 * cos(w0(10));
    % a2(10) = 1 - alpha(10) / A(10);
    b0(10) = A(10)*( (A(10)+1) + (A(10)-1)*cos(w0(10)) + 2*sqrt(A(10))*alpha(10) );
    b1(10) = -2*A(10)*( (A(10)-1) + (A(10)+1)*cos(w0(10)) );
    b2(10) = A(10)*( (A(10)+1) + (A(10)-1)*cos(w0(10)) - 2*sqrt(A(10))*alpha(10) );
    a0(10) = (A(10)+1) - (A(10)-1)*cos(w0(10)) + 2*sqrt(A(10))*alpha(10);
    a1(10) = 2*( (A(10)-1) - (A(10)+1)*cos(w0(10)) );
    a2(10) = (A(10)+1) - (A(10)-1)*cos(w0(10)) - 2*sqrt(A(10))*alpha(10);
    

    for i=1:10
        num(50*index+5*i-4)=b0(i)/a0(i)/2;
        num(50*index+5*i-3)=b1(i)/a0(i)/2;
        num(50*index+5*i-2)=b2(i)/a0(i)/2;
        num(50*index+5*i-1)=a1(i)/a0(i)/2;
        num(50*index+5*i)=a2(i)/a0(i)/2;
    end
end
    
audioIn=peoAudio;
audio_temp=audioIn;
for i=1:10
    % 确保音频是立体声的
    if size(audioIn, 2) ~= 2
        num_temp=num((dB(i)+12)*50+(i-1)*5+1:(dB(i)+12)*50+(i-1)*5+3);
        den_temp=[0.5,num((dB(i)+12)*50+(i-1)*5+4:(dB(i)+12)*50+(i-1)*5+5)];
        audioOut = filter(num_temp, den_temp, audio_temp);
        audio_temp=audioOut;
    else
        % 分离左右声道
        leftChannel = audio_temp(:, 1);
        rightChannel = audio_temp(:, 2);
        
        num_temp=num((dB(i)+12)*50+(i-1)*5+1:(dB(i)+12)*50+(i-1)*5+3);
        den_temp=[0.5,num((dB(i)+12)*50+(i-1)*5+4:(dB(i)+12)*50+(i-1)*5+5)];
        % 应用滤波器到每个声道
        leftOut = filter(num_temp, den_temp, leftChannel);
        rightOut = filter(num_temp, den_temp, rightChannel);

        % 合并处理后的声道
        audioOut = [leftOut, rightOut];
        audio_temp=audioOut;
    end
end


% 保存处理后的音频为一个新的文件
audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪分离.wav', processedAudio, fs);
audiowrite('C:\Users\zheng\Desktop\FPGA_gowim\春庭雪人声.wav', audioOut, fs);
